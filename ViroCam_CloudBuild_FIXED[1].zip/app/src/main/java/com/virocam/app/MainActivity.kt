package com.virocam.app

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080A10)
private val Card = Color(0xFF111521)
private val Accent = Color(0xFF8B6CFF)
private val Cyan = Color(0xFF4DD9FF)
private val Muted = Color(0xFF8992A7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ViroCamApp() }
    }
}

@Composable
fun ViroCamApp() {
    var tab by remember { mutableIntStateOf(0) }
    var showRecord by remember { mutableStateOf(false) }
    var showAmbient by remember { mutableStateOf(false) }
    val permissions = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {}

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Card, primary = Accent,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (showRecord) {
                RecordScreen(
                    onBack = { showRecord = false },
                    onPermission = {
                        permissions.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
                    }
                )
            } else if (showAmbient) {
                AmbientScreen(onBack = { showAmbient = false })
            } else {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(1f)) {
                        when (tab) {
                            0 -> HomeScreen(
                                onRecord = { showRecord = true },
                                onAmbient = { showAmbient = true }
                            )
                            1 -> GalleryScreen()
                            2 -> TrashScreen()
                            3 -> SettingsScreen()
                        }
                    }
                    NavigationBar(containerColor = Color(0xFF0D1019)) {
                        val items = listOf(
                            "Home" to Icons.Default.Home,
                            "Gallery" to Icons.Default.VideoLibrary,
                            "Trash" to Icons.Default.DeleteOutline,
                            "Settings" to Icons.Default.Settings
                        )
                        items.forEachIndexed { i, item ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Icon(item.second, null) },
                                label = { Text(item.first) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onRecord: () -> Unit, onAmbient: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("VIROCAM", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Camera • Audio • Control", color = Muted, fontSize = 13.sp)
                }
                Icon(Icons.Default.Tune, null, tint = Accent)
            }
        }
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
                Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("READY", color = Cyan, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Box(
                        Modifier.size(150.dp).background(Accent.copy(alpha=.14f), CircleShape)
                            .clickable { onRecord() },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(112.dp).background(Accent, CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Videocam, null, modifier = Modifier.size(48.dp), tint = Color.White)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("START RECORDING", fontWeight = FontWeight.Bold)
                    Text("Camera and microphone are inactive", color = Muted, fontSize = 12.sp)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard("Camera", "Rear • 1080p", Icons.Default.CameraAlt, Modifier.weight(1f))
                QuickCard("Audio", "Mic enabled", Icons.Default.Mic, Modifier.weight(1f))
            }
        }
        item {
            Card(
                Modifier.fillMaxWidth().clickable { onAmbient() },
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF151229))
            ) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Headphones, null, tint = Cyan, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text("AMPLIFY SOUND", fontWeight = FontWeight.Bold)
                        Text("Monitor ambient audio through Bluetooth", color = Muted, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
        }
        item { StorageCard() }
    }
}

@Composable
fun QuickCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
        Column(Modifier.padding(16.dp)) {
            Icon(icon, null, tint = Accent)
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(value, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun StorageCard() {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
        Column(Modifier.padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Storage", fontWeight = FontWeight.Bold)
                Text("42.8 GB free", color = Cyan, fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(progress = { .42f }, modifier = Modifier.fillMaxWidth(),
                color = Accent, trackColor = Color(0xFF252B3A))
            Spacer(Modifier.height(8.dp))
            Text("72.2 GB used • 115 GB total", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun RecordScreen(onBack: () -> Unit, onPermission: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text("Recorder", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF151820)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.CameraAlt, null, modifier = Modifier.size(64.dp), tint = Muted)
                Text("Camera preview", color = Muted)
            }
        }
        Row(Modifier.fillMaxWidth().padding(24.dp), horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {}) { Icon(Icons.Default.FlashAuto, null, tint = Color.White) }
            FloatingActionButton(onClick = onPermission, containerColor = Accent, modifier = Modifier.size(76.dp)) {
                Icon(Icons.Default.FiberManualRecord, null)
            }
            IconButton(onClick = {}) { Icon(Icons.Default.Cameraswitch, null, tint = Color.White) }
        }
    }
}

@Composable
fun AmbientScreen(onBack: () -> Unit) {
    var active by remember { mutableStateOf(false) }
    var gain by remember { mutableFloatStateOf(.45f) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("Amplify Sound", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(20.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.BluetoothAudio, null, tint = Cyan, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("Bluetooth audio", fontWeight = FontWeight.Bold)
                        Text("Connect TWS or another supported device", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text("Device")
                Text("No Bluetooth device selected", color = Muted, fontSize = 12.sp)
                OutlinedButton(onClick = {}) { Text("Choose device") }
            }
        }
        Spacer(Modifier.height(16.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
            Column(Modifier.padding(20.dp)) {
                Text("Ambient level", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(20.dp))
                LinearProgressIndicator(progress = { if (active) .62f else .08f }, modifier = Modifier.fillMaxWidth(),
                    color = Cyan, trackColor = Color(0xFF252B3A))
                Spacer(Modifier.height(18.dp))
                Text("Amplification", fontWeight = FontWeight.Bold)
                Slider(value = gain, onValueChange = { gain = it }, valueRange = 0f..1f)
                Text(if (active) "Monitoring active" else "Monitoring stopped", color = if (active) Cyan else Muted)
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = { active = !active }, Modifier.fillMaxWidth().height(56.dp)) {
            Text(if (active) "STOP LISTENING" else "START LISTENING")
        }
        Spacer(Modifier.height(10.dp))
        Text("Use only with the people and environments where you are authorized to monitor audio.",
            color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun GalleryScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Gallery", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Your recordings", color = Muted)
        Spacer(Modifier.height(18.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(6) { i ->
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
                    Column {
                        Box(Modifier.fillMaxWidth().height(130.dp).background(Color(0xFF1B2130)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.PlayCircle, null, tint = Accent, modifier = Modifier.size(44.dp))
                        }
                        Column(Modifier.padding(12.dp)) {
                            Text("Recording ${i + 1}", fontWeight = FontWeight.SemiBold)
                            Text("00:${12 + i} • 1080p", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrashScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Trash", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Deleted items can be restored or permanently removed.", color = Muted)
        Spacer(Modifier.height(22.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DeleteSweep, null, tint = Accent)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Trash is empty", fontWeight = FontWeight.Bold)
                    Text("Deleted recordings will appear here.", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        item { Text("Camera", color = Accent, fontWeight = FontWeight.Bold) }
        item { SettingRow("Camera", "Rear camera", Icons.Default.CameraAlt) }
        item { SettingRow("Resolution", "1080p", Icons.Default.HighQuality) }
        item { SettingRow("Frame rate", "30 FPS", Icons.Default.Speed) }
        item { Text("Audio", color = Accent, fontWeight = FontWeight.Bold) }
        item { SettingRow("Microphone", "Enabled", Icons.Default.Mic) }
        item { SettingRow("Ambient sound", "Bluetooth monitoring", Icons.Default.Headphones) }
        item { Text("Security", color = Accent, fontWeight = FontWeight.Bold) }
        item { SettingRow("Biometric lock", "Available on supported devices", Icons.Default.Fingerprint) }
        item { Text("Appearance", color = Accent, fontWeight = FontWeight.Bold) }
        item { SettingRow("Theme", "AMOLED Dark", Icons.Default.DarkMode) }
        item { Text("Storage & device", color = Accent, fontWeight = FontWeight.Bold) }
        item { SettingRow("Storage", "72.2 GB / 115 GB", Icons.Default.Storage) }
        item { SettingRow("RAM", "Device information", Icons.Default.Memory) }
    }
}

@Composable
fun SettingRow(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
        Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Accent)
            Spacer(Modifier.width(15.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(value, color = Muted, fontSize = 11.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}
