# ViroCam

A new Android camera/audio utility UI prototype.

## Included
- Home dashboard
- Recorder UI
- Gallery UI
- Trash UI
- Settings UI
- Ambient Sound/Bluetooth monitoring UI
- Storage/RAM information placeholders
- Camera/microphone permission flow
- CameraX, Media3 and Biometric dependencies ready for implementation

## Build
Open the project in Android Studio with a recent Android SDK installed.

Then:
Build > Generate App Bundle(s) / APK(s) > Generate APK(s)

The generated debug APK is normally under:
app/build/outputs/apk/debug/app-debug.apk

## Important
This initial project is a UI/prototype foundation. The Gallery, Trash persistence, foreground recording service, Bluetooth audio processing, and biometric enforcement still need their production implementations and device testing.


## Cloud build

See `CLOUD_BUILD.md`. A GitHub Actions workflow is included so the debug APK can be built on a GitHub-hosted runner without a PC-side Android SDK.
