# ViroCam Cloud Build — corrected workflow

This package contains a corrected GitHub Actions workflow.

The previous workflow used an older Android SDK setup action that could request
the retired `tools` SDK package. Google no longer serves that package. This
version uses `android-actions/setup-android@v4` and requests only
`platform-tools`, then installs the required Android 35 platform and build tools.

## Important

You must replace the old `.github/workflows/build-apk.yml` in your GitHub
repository with the workflow from this ZIP.

After committing the replacement workflow:
1. Open Actions.
2. Select Build ViroCam APK.
3. Run workflow.
4. Wait for the green check.
5. Open the successful run.
6. Under Artifacts, download `ViroCam-debug-apk`.
7. Extract it and install `app-debug.apk`.

The current project remains a UI/prototype foundation. Production implementations
for persistent Gallery/Trash, foreground camera recording, Bluetooth audio processing,
and biometric enforcement still require further development.
